
function Footer() {
    return (
       
        <footer className="footer">
            <p>&copy; {new Date().getFullYear() } Community Sports Facility Management</p>
        </footer>
    );
}

export default Footer